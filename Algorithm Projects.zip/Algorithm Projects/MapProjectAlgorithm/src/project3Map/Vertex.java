package project3Map;


import java.util.LinkedList;


public class Vertex implements Comparable<Vertex>
{
	// Data fields
	private String name;
	private double xCo, yCo;
	private double distance;
	private Vertex path;
	private LinkedList<Vertex> adjacentCities = new LinkedList<>();
	private String type;
	double gValue;
	double h_scores;
	double fValue=0;
	

	// Constructors
	public Vertex(String name, double xCo, double yCo, String type)
	{
		this.name = name;
		this.xCo = xCo;
		this.yCo = yCo;
		this.type = type;
	}

	// Add an adjacent to a vertex
	// edge constructor
	public void addAdjacent(Vertex adjacentCity)
	{
		// add first to the linked list
		adjacentCities.addFirst(adjacentCity);
	}

	// Getters and Setters
	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public double getxCo()
	{
		return xCo;
	}

	public void setxCo(double xCo)
	{
		this.xCo = xCo;
	}

	public double getyCo()
	{
		return yCo;
	}

	public void setyCo(double yCo)
	{
		this.yCo = yCo;
	}

	public void setDistance(double distance)
	{
		this.distance = distance;
	}

	public double getDistance()
	{
		return distance;
	}

	public Vertex getPath()
	{
		return path;
	}

	public void setPath(Vertex path)
	{
		this.path = path;
	}

	//not used anywhere
	public void setAdjacentCities(LinkedList<Vertex> leavingMe)
	{
		this.adjacentCities = leavingMe;
	}

	//used in dijkstra algo
	public LinkedList<Vertex> getAdjacentCities()
	{
		return adjacentCities;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	// Comparator
	@Override
	public int compareTo(Vertex other)
	{
		return Double.compare(distance, other.getDistance());
	}
}

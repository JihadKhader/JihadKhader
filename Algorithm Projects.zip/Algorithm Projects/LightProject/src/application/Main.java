package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			// HBOX
		//	HBox box = new HBox();
//			Scroll
			ListView<Circle> listView = new ListView<>();
			ListView<HBox> listViewH = new ListView<>();
			
			ObservableList<Circle> circles1 = FXCollections.observableArrayList(m1(listView));
			System.out.println(circles1);
//			listView.set
			listView.setItems(circles1);
			listView.setOrientation(Orientation.HORIZONTAL);
			listView.setPrefSize(400, 100);
			listView.setTranslateX(350);
			listView.setTranslateY(300);
			
			ListView<Circle> listView2 = new ListView<>();
			ObservableList<Circle> circles2 = FXCollections.observableArrayList(m2(listView2));
			listView2.setItems(circles2);
			listView2.setOrientation(Orientation.HORIZONTAL);
			listView2.setPrefSize(400, 100);
			listView2.setTranslateX(350);
			listView2.setTranslateY(500);

			Pane test = new Pane();
			Label labelFile = new Label("no files selected");
			labelFile.setTranslateX(445);
			labelFile.setTranslateY(130);
			labelFile.setTextFill(Color.BLACK);
			labelFile.setBackground(
					new Background(new BackgroundFill(Color.PALEGOLDENROD, CornerRadii.EMPTY, Insets.EMPTY)));
			labelFile.setPadding(new Insets(10));
			Label labelTitle = new Label("Light System");
			labelTitle.setTranslateX(400);
			labelTitle.setTranslateY(50);
			labelTitle.setFont(new Font("Lucida Sans Unicode", 30));
			labelTitle.setTextFill(Color.DARKOLIVEGREEN);
			labelTitle.setBackground(
					new Background(new BackgroundFill(Color.PALEGOLDENROD, CornerRadii.EMPTY, Insets.EMPTY)));
			labelTitle.setPadding(new Insets(10));
			Button fileChoose = new Button("Choose Files from a directory");
			fileChoose.setStyle("-fx-background-color: DarkOliveGreen");
			fileChoose.setTranslateX(410);
			fileChoose.setTranslateY(180);
			fileChoose.setTextFill(Color.WHITE);
			ScrollPane scrollForShapes = new ScrollPane();
//			((Object) scrollForShapes).setBounds(200, 300, 150, 150);

			Button start = new Button("Start");
			start.setStyle("-fx-background-color: DarkOliveGreen");
			start.setTranslateX(480);
			start.setTranslateY(210);
			start.setTextFill(Color.WHITE);
			for (int i = 0; i <= 5; i++) {
				Circle circle = new Circle();
				circle.setCenterX(300 + (i * 80));
				circle.setCenterY(275);
				circle.setRadius(20);
				circle.setFill(Color.PINK);
				circle.setStroke(Color.BLACK);
				test.getChildren().add(circle);
			}
			Circle circle = new Circle();
			circle.setCenterX(200);
			circle.setCenterY(175);
			circle.setRadius(10);
			circle.setFill(Color.CADETBLUE);
			circle.setStroke(Color.BLACK);

			StackPane stackP = new StackPane();
//			stackP.getChildren().addAll(scrollForShapes);
			Scene scene = new Scene(test, 1000, 700);

			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			BackgroundImage myBackgroudImage = new BackgroundImage(new Image(
					"/fx/beautiful-flight-over-the-circuit-board-with-running-green-lights-looped-3d-animation-of-videos_csp56166150_auto_x2.png",
					1032, 1032, false, true), BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
					BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Open Resource Files");
			fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.txt"));
			EventHandler<ActionEvent> fileChoosing = new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent arg0) {
					File selectedFile = fileChooser.showOpenDialog(primaryStage);
					if (selectedFile != null) {
						labelFile.setText(selectedFile.getAbsolutePath());
						labelFile.setTextFill(Color.DARKOLIVEGREEN);
					}
				}

			};

//			File selectedFile = fileChooser.showOpenDialog(primaryStage);
//			if (selectedFile != null) {
//				labelFile.setText(selectedFile.getAbsolutePath());
//				labelFile.setTextFill(Color.DARKOLIVEGREEN);
//			}
			fileChoose.setOnAction(fileChoosing);
			test.setBackground(new Background(myBackgroudImage));
			test.getChildren().addAll(labelTitle, labelFile, fileChoose, start, circle, listView, listView2);
//			scrollForShapes.setco
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void readFile(File file1) throws IOException {
		for (File fileMethod : file1.listFiles()) {
			if (fileMethod.isFile()) {
				BufferedReader input = null;
				String line = "";
				try {
					input = new BufferedReader(new FileReader(fileMethod));
					while ((line = input.readLine()) != null) {
//						Frequency f = new Frequency(fileMethod.getName(), line);
//						BabyTree b = new BabyTree(f, line);
//						AVLTree.insert(b);
					}

				} catch (FileNotFoundException e) {
					System.out.println(e);
				} finally {
					if (input != null) {
						input.close();
					}
				}
			}
		}
	}

//	public static Circle m(ListView<Circle> list) {
//		Circle circle = new Circle();
//		
//		for (int i = 0; i <= 5; i++) {
//			circle.setCenterX(300 + (i * 80));
//			circle.setCenterY(275);
//			circle.setRadius(20);
//			circle.setFill(Color.BLUE);
//			circle.setStroke(Color.BLACK);
//			ObservableList<Circle> circles = FXCollections.observableArrayList(circle);
//			list.setItems(circles);
//		}
//		return circle;
//	}
	public static ObservableList m(ListView<Circle> list) {
		Circle circle = new Circle();
		Circle circle1 = new Circle();
		Circle circle2 = new Circle();
		Circle circle3 = new Circle();
		Circle circle4 = new Circle();
		Circle circle5 = new Circle();
		Circle circle7 = new Circle();

		circle.setCenterX(300 + (1 * 80));
		circle.setCenterY(275);
		circle.setRadius(20);
		circle.setFill(Color.BLUE);
		circle.setStroke(Color.BLACK);
		circle1.setCenterX(300 + (2 * 80));
		circle1.setCenterY(275);
		circle1.setRadius(20);
		circle1.setFill(Color.BLUE);
		circle1.setStroke(Color.BLACK);
		circle2.setCenterX(300 + (3 * 80));
		circle2.setCenterY(275);
		circle2.setRadius(20);
		circle2.setFill(Color.BLUE);
		circle2.setStroke(Color.BLACK);
		circle3.setCenterX(300 + (4 * 80));
		circle3.setCenterY(275);
		circle3.setRadius(20);
		circle3.setFill(Color.BLUE);
		circle3.setStroke(Color.BLACK);
		circle4.setCenterX(300 + (5 * 80));
		circle4.setCenterY(275);
		circle4.setRadius(20);
		circle4.setFill(Color.BLUE);
		circle4.setStroke(Color.BLACK);
		circle5.setCenterX(300 + (6 * 80));
		circle5.setCenterY(275);
		circle5.setRadius(20);
		circle5.setFill(Color.BLUE);
		circle5.setStroke(Color.BLACK);
		ObservableList<Circle> circles = FXCollections.observableArrayList(circle, circle1, circle2, circle3, circle4,
				circle5);
		ObservableList<Circle> circles1 = FXCollections.observableArrayList(circle7);
		ObservableList<Circle> circles2 = FXCollections.observableArrayList();

		for (int i = 0; i < 5; i++) {
			circle.setCenterX(300 + (i * 80));
			circle.setCenterY(275);
			circle.setRadius(20);
			circle.setFill(Color.BLUE);
			circle.setStroke(Color.BLACK);
//			list.setItems(circles1);
//			circles2 = FXCollections.observableArrayList(circle);
//			circles2.addAll(circle);
//			circles1 = FXCollections.observableArrayList(circle);
//			list.setItems((ObservableList<Circle>) circle);
			circles2 = FXCollections.observableArrayList(circle);
			list.getSelectionModel().getSelectedItem();
			list.setItems(circles2);
		}
		list.setItems(circles2);

		return circles2;
	}

//	public static ObservableList<Circle> m1(ListView<Circle> list) {
//		int x = 0;
//		Circle circle = new Circle();
//		ObservableList<Circle> circles = FXCollections.observableArrayList();
//		while (x <= 5) {
//			circle.setCenterX(300 + (x * 80));
//			circle.setCenterY(275);
//			circle.setRadius(20);
//			circle.setFill(Color.BLUE);
//			circle.setStroke(Color.BLACK);
////			circles = list.getSelectionModel().getSelectedItems();
//			list.setItems(circles);
//			circles = FXCollections.observableArrayList(circle);
//			x++;
//
//
//		}
//
//		return circles;
//
//	}
//	public static ObservableList<Circle> m1(ListView<Circle> list) {
//		ArrayList<Circle> arr = new ArrayList<>();
//		int x = 0;
//		Circle circle = new Circle();
//		ObservableList<Circle> circles = FXCollections.observableArrayList();
//		while (x <= 5) {
//			circle.setCenterX(300 + (x * 80));
//			circle.setCenterY(275);
//			circle.setRadius(20);
//			circle.setFill(Color.BLUE);
//			circle.setStroke(Color.BLACK);
////			circles = list.getSelectionModel().getSelectedItems();
//			arr.add(circle);
//			list.getItems().addAll(arr);
////			list.setItems(circles);
//			circles = FXCollections.observableArrayList(circle);
//			x++;
//
//		}
//
//		return circles;
//
//	}

	static ArrayList<Circle> cirArr = new ArrayList<Circle>();

//	static ObservableList<Circle> spawnCircles(ListView<Circle> list) {
//		if(cirArr.size() < 20) {
//			createCircle();
//		}
//		return null;
//	}
//	static void createCircle() {
//		Circle circle = new Circle();
//		int x = 0;
//		
//		while(x < 20) {
//			circle.setCenterX(300 + (x * 80));
//			circle.setCenterY(275);
//			circle.setRadius(20);
//			circle.setFill(Color.BLUE);
//			circle.setStroke(Color.BLACK);
//			cirArr.add(circle);
//			x++;
//		}
//	}
//	void createCircle() {
//		Circle circle = new Circle();
//		int x = 0;
//		while(x < 10) {
//			circle.setCenterX(300 + (x * 80));
//			circle.setCenterY(275);
//			circle.setRadius(20);
//			circle.setFill(Color.BLUE);
//			circle.setStroke(Color.BLACK);
//			cirArr.add(circle);
//			x++;
//		}
//	}
	public static Circle test() {
		ArrayList<Circle> arr = new ArrayList<>();

		return null;

	}

	public void addCircle(int r) {
		ArrayList<Circle> arr = new ArrayList<>();

		arr.add(new Circle(r));
	}
	public static ObservableList<Circle> m1(ListView<Circle> list) {
		ArrayList<Circle> arr = new ArrayList<>();
		Circle circle = new Circle();
		ObservableList<Circle> circles = FXCollections.observableArrayList();
//		list.s
		for (int i = 0; i <= 5; i++) {
			circle.setCenterX(300 + (i * 80));
			circle.setCenterY(275);
			circle.setRadius(20);
			circle.setFill(Color.PINK);
			circle.setStroke(Color.BLACK);
			list.getItems().addAll(arr);
		}
//		for (int x = 1; x <= 10; x++) {
////			circle.setCenterX(300 + (x * 10));
////			circle.setCenterY(275);
//			circle.setRadius(30);
//			circle.setFill(Color.BLUE);
//			circle.setStroke(Color.BLACK);
//			arr.add(circle);
//			list.getItems().addAll(arr);
//
//		}
		circles = FXCollections.observableArrayList(arr);

		return circles;

	}
//	public static ObservableList<Circle> m1(ListView<Circle> list) {
//		ArrayList<Circle> arr = new ArrayList<>();
//		Circle circle = new Circle();
//		ObservableList<Circle> circles = FXCollections.observableArrayList();
////		list.s
//		for (int x = 1; x <= 10; x++) {
////			circle.setCenterX(300 + (x * 10));
////			circle.setCenterY(275);
//			circle.setRadius(30);
//			circle.setFill(Color.BLUE);
//			circle.setStroke(Color.BLACK);
//			arr.add(circle);
//			list.getItems().addAll(arr);
//
//		}
//		circles = FXCollections.observableArrayList(arr);
//
//		return circles;
//
//	}
	public static ObservableList<HBox> m1H(ListView<HBox> list) {
		HBox box = new HBox();
		ArrayList<Circle> arr = new ArrayList<>();
		Circle circle = new Circle();
		ObservableList<HBox> circles = FXCollections.observableArrayList();
//		list.s
		for (int x = 1; x <= 10; x++) {
//			circle.setCenterX(300 + (x * 10));
//			circle.setCenterY(275);
			circle.setRadius(30);
			circle.setFill(Color.BLUE);
			circle.setStroke(Color.BLACK);
			arr.add(circle);
			

		}
		box.getChildren().addAll(arr);
		list.getItems().add(box);


		circles = FXCollections.observableArrayList(box);

		return circles;

	}
//	//Main M2
//	public static ObservableList<Circle> m2(ListView<Circle> list1) {
//		ArrayList<Circle> arr = new ArrayList<>();
//		Circle circle = new Circle();
//		ObservableList<Circle> circles = FXCollections.observableArrayList();
//		for (int x = 1; x <= 10; x++) {
////			circle.setCenterX(300 + (x * 10));
////			circle.setCenterY(275);
//			circle.setRadius(30);
//			circle.setFill(Color.BLUE);
//			circle.setStroke(Color.BLACK);
//			arr.add(circle);
//			list1.getItems().addAll(circle);
//
//		}
//		circles = FXCollections.observableArrayList(arr);
//
//		return circles;
//
//	}

	public static ObservableList<Circle> m2(ListView<Circle> list1) {
		ObservableList<Circle> list = FXCollections.observableArrayList();
		list.addListener(new InvalidationListener() {

			@Override
			public void invalidated(Observable arg0) {
				System.out.println("Listen invalieded");
			}
		});
		list1.setItems(list);
		ArrayList<Circle> arr = new ArrayList<>();
		Circle circle = new Circle();
		ObservableList<Circle> circles = FXCollections.observableArrayList();

		for (int x = 1; x <= 11; x++) {
//				Circle main = new Circle();
//				circle.setCenterX(300 + (x * 10));
//				circle.setCenterY(275);
			circle.setRadius(30);
			circle.setFill(Color.PINK);
			circle.setStroke(Color.BLACK);
//				System.out.println(arr.get(x));
			System.out.println("test0");
			circles.add(circle);

			list1.getItems().add(circle);
			arr.add(circle);

			System.out.println("test1");

		}
		System.out.println(arr + "" + arr.indexOf(circles));
		circles = FXCollections.observableArrayList(arr);
		list1.setItems(circles);
		System.out.println("Wisam");
		System.out.println(circles);
		return circles;

	}

	public static void main(String[] args) {
		launch(args);
	}
}

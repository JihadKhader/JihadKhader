package com.example.pro4tic;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class Unbeatable {
	private boolean turnX = true;
	ArrayList<Button> arr = new ArrayList<Button>();
	String[] test = new String[9];
	@FXML
	private Button b1;
	@FXML
	private Button b2;
	@FXML
	private Button b3;
	@FXML
	private Button b4;
	@FXML
	private Button b5;
	@FXML
	private Button b6;
	@FXML
	private Button b7;
	@FXML
	private Button b8;
	@FXML
	private Button b9;
	@FXML
	private Button back;
	@FXML
	private Label state;
	@FXML
	private Button tryAgain;

	public void back(ActionEvent actionEvent) throws IOException {
		Node node = (Node) actionEvent.getSource();
		Stage thisStage = (Stage) node.getScene().getWindow();
		thisStage.hide();

		Stage stage = new Stage();
		FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("root.fxml"));
		Scene scene = new Scene(fxmlLoader.load(), 415, 380);
		stage.setScene(scene);
		stage.show();
		stage.setResizable(false);
		stage.setTitle("Unbeatable");

	}

	public void again(ActionEvent actionEvent) throws IOException {
		Node node = (Node) actionEvent.getSource();
		Stage thisStage = (Stage) node.getScene().getWindow();
		thisStage.hide();

		Stage stage = new Stage();
		FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("root3.fxml"));
		Scene scene = new Scene(fxmlLoader.load(), 450, 518);
		stage.setScene(scene);
		stage.show();
		stage.setResizable(false);
		stage.setTitle("Unbeatable");

	}

	public void initialize() {
		// add buttons to the array of buttons 
		arr.add(b1);
		arr.add(b2);
		arr.add(b3);
		arr.add(b4);
		arr.add(b5);
		arr.add(b6);
		arr.add(b7);
		arr.add(b8);
		arr.add(b9);
		// start with x "Computer" as the first button
//		b1.setText("X");
//		b1.setDisable(true);
//		b1.setFont(Font.font(70));
//		b1.setStyle("-fx-background-color: Red");
//		b1.setTextFill(Color.LEMONCHIFFON);
//		
		// for loop to iterate for each button
		for (int i = 0; i < arr.size(); i++) {
			//Integer variable test to the initial start
			int test = i;
			
			arr.get(i).setOnAction(e -> {
				// add "O" the human player turn
				arr.get(test).setText("O");
				arr.get(test).setFont(Font.font(70));
				arr.get(test).setDisable(true);
				arr.get(test).setStyle("-fx-background-color: DarkOliveGreen");
				arr.get(test).setTextFill(Color.LEMONCHIFFON);
				// Because it is turn the human "O" then the computer turn is False
				turnX = false;
				// check method it checks if x Wins
				if (check().equals("X")) {
					state.setText("X Wons!");
					for (int x = 0; x < arr.size(); x++) {
						arr.get(x).setDisable(true);

					}
				// check method it checks if o wins
				} else if (check().equals("O")) {
					state.setText("O Wons!");
					for (int x = 0; x < arr.size(); x++) {
						arr.get(x).setDisable(true);

					}
				// check if tie
				} else if (check().equals("tie")) {
					boolean temp = false;
					for (int j = 0; j < arr.size(); j++) {
						if (arr.get(j).getText().equalsIgnoreCase("")) {
							temp = true;
						}
					}
					
					if (!temp) {
						state.setText("tie !");
					}
				}
				// while it is turnX 
				while (true) {
					// variable that detects the location for the computer to choose
					int c = detect();
					
					if (arr.get(c).getText().equals("")) {
						arr.get(c).setText("X");
						arr.get(c).setStyle("-fx-background-color: Red");
						arr.get(c).setTextFill(Color.LEMONCHIFFON);
						arr.get(c).setFont(Font.font(70));
						arr.get(c).setDisable(true);
						turnX = false;
						break;
					}
				}
				if (check().equals("X")) {
					state.setText("X Wons!");
					for (int x = 0; x < arr.size(); x++) {
						arr.get(x).setDisable(true);
					}
				} else if (check().equals("O")) {
					state.setText("O Wons!");
					for (int x = 0; x < arr.size(); x++) {
						arr.get(x).setDisable(true);
					}
				} else if (check().equals("tie")) {
					boolean temp = false;
					for (int j = 0; j < arr.size(); j++) {
						if (arr.get(j).getText().equalsIgnoreCase("")) {
							temp = true;
						}
					}
					if (!temp) {
						state.setText("tie !");
					}
				}
			});

		}
	}

	// method detect that gives the computer the destination to go for never loosing
	private int detect() {
		// for loop that iterate in the array
		for (int i = 0; i < test.length; i++) {
			// get text for the choosing button
			test[i] = arr.get(i).getText();
		}
		
		int m = 0;
		int max = -1;
		int location = 0;
		// for loop that iterate in the array 
		for (int j = 0; j < test.length; j++) {
			// if the board is clear - button clear
			if (arr.get(j).getText().equalsIgnoreCase("")) {
				
				test[j] = "X";
				// recursion to the minmax
				m = minmax(test, true);
				test[j] = "";
				if (m > max) {
					max = m;
					location = j;
				}
			}
		}
		return location;
	}
	
	private int minmax(String[] test, boolean turnHuman) {
		if (checkMin().equalsIgnoreCase("X")) {
			return 1;
		} else if (checkMin().equalsIgnoreCase("O")) {
			return -1;
		} else if (checkTie().equalsIgnoreCase("tie")) {
			return 0;
		} else {
			// Human
			if (turnHuman) {
				int max = 1;
				for (int j = 0; j < test.length; j++) {
					if (test[j].equalsIgnoreCase("")) {
						test[j] = "O";
						int m = minmax(test, false);
						test[j] = "";
						if (m < max) {
							max = m;
						}
					}
				}
				return max;
			} else {
				int max = -1;
				for (int j = 0; j < test.length; j++) {
					if (test[j].equalsIgnoreCase("")) {
						test[j] = "X";
						int m = minmax(test, true);
						test[j] = "";
						if (m > max) {
							max = m;
						}
					}
				}
				return max;
			}
		}
	}

	private String checkTie() {
		boolean temp = false;
		for (int i = 0; i < test.length; i++) {
			if (test[i].equalsIgnoreCase("")) {
				temp = true;
			}
		}
		if (!temp) {
			return "tie";
		} else {
			return "";
		}
	}

	private String checkMin() {
		// ------>
		if ((test[0].equalsIgnoreCase("X") && test[1].equalsIgnoreCase("X") && test[2].equalsIgnoreCase("X"))
				|| (test[0].equalsIgnoreCase("O") && test[1].equalsIgnoreCase("O") && test[2].equalsIgnoreCase("O"))) {
			return test[0];
		} else if ((test[3].equalsIgnoreCase("X") && test[4].equalsIgnoreCase("X") && test[5].equalsIgnoreCase("X"))
				|| (test[3].equalsIgnoreCase("O") && test[4].equalsIgnoreCase("O") && test[5].equalsIgnoreCase("O"))) {
			return test[3];
		} else if ((test[6].equalsIgnoreCase("X") && test[7].equalsIgnoreCase("X") && test[8].equalsIgnoreCase("X"))
				|| (test[6].equalsIgnoreCase("O") && test[7].equalsIgnoreCase("O") && test[8].equalsIgnoreCase("O"))) {
			return test[6];

		}
//        |
//        |
//        |
//        
		else if ((test[0].equalsIgnoreCase("X") && test[3].equalsIgnoreCase("X") && test[6].equalsIgnoreCase("X"))
				|| (test[0].equalsIgnoreCase("O") && test[3].equalsIgnoreCase("O") && test[6].equalsIgnoreCase("O"))) {
			return test[0];

		} else if ((test[1].equalsIgnoreCase("X") && test[4].equalsIgnoreCase("X") && test[7].equalsIgnoreCase("X"))
				|| (test[1].equalsIgnoreCase("O") && test[4].equalsIgnoreCase("O") && test[7].equalsIgnoreCase("O"))) {
			return test[1];

		} else if ((test[2].equalsIgnoreCase("X") && test[5].equalsIgnoreCase("X") && test[8].equalsIgnoreCase("X"))
				|| (test[2].equalsIgnoreCase("O") && test[5].equalsIgnoreCase("O") && test[8].equalsIgnoreCase("O"))) {
			return test[2];

		}

		// diagonal
		else if ((test[0].equalsIgnoreCase("X") && test[4].equalsIgnoreCase("X") && test[8].equalsIgnoreCase("X"))
				|| (test[0].equalsIgnoreCase("O") && test[4].equalsIgnoreCase("O") && test[8].equalsIgnoreCase("O"))) {
			return test[0];

		} else if ((test[2].equalsIgnoreCase("X") && test[4].equalsIgnoreCase("X") && test[6].equalsIgnoreCase("X"))
				|| (test[2].equalsIgnoreCase("O") && test[4].equalsIgnoreCase("O") && test[6].equalsIgnoreCase("O"))) {
			return test[2];

		} else {
			return "tie";
		}
	}

	private String check() {
		// horizontal 
		if ((b1.getText().equals("X") && b2.getText().equals("X") && b3.getText().equals("X"))
				|| (b1.getText().equals("O") && b2.getText().equals("O") && b3.getText().equals("O"))) {
			return b1.getText();
		} else if ((b4.getText().equals("X") && b5.getText().equals("X") && b6.getText().equals("X"))
				|| (b4.getText().equals("O") && b5.getText().equals("O") && b6.getText().equals("O"))) {
			return b4.getText();
		} else if ((b7.getText().equals("X") && b8.getText().equals("X") && b9.getText().equals("X"))
				|| (b7.getText().equals("O") && b8.getText().equals("O") && b9.getText().equals("O"))) {
			return b7.getText();

		}
		// vertical
		else if ((b1.getText().equals("X") && b4.getText().equals("X") && b7.getText().equals("X"))
				|| (b1.getText().equals("O") && b4.getText().equals("O") && b7.getText().equals("O"))) {
			return b1.getText();

		} else if ((b2.getText().equals("X") && b5.getText().equals("X") && b8.getText().equals("X"))
				|| (b2.getText().equals("O") && b5.getText().equals("O") && b8.getText().equals("O"))) {
			return b2.getText();

		} else if ((b3.getText().equals("X") && b6.getText().equals("X") && b9.getText().equals("X"))
				|| (b3.getText().equals("O") && b6.getText().equals("O") && b9.getText().equals("O"))) {
			return b3.getText();

		}

		// diagonal
		else if ((b1.getText().equals("X") && b5.getText().equals("X") && b9.getText().equals("X"))
				|| (b1.getText().equals("O") && b5.getText().equals("O") && b9.getText().equals("O"))) {
			return b1.getText();

		} else if ((b3.getText().equals("X") && b5.getText().equals("X") && b7.getText().equals("X"))
				|| (b3.getText().equals("O") && b5.getText().equals("O") && b7.getText().equals("O"))) {
			return b3.getText();

		} else {
			return "tie";
		}
	}

}

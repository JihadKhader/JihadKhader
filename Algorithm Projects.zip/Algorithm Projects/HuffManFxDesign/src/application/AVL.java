package application;

public class AVL {
	char character;
	String huffman;
	AVL left;
	AVL right;

	public AVL() {
		character = '\0';
		huffman = "";
		left = right = null;

	}

	public AVL(char character, String huffman) {
		this.character = character;
		this.huffman = huffman;
		left = right = null;
	}

	public static AVL addEntry(AVL tree, String str, int ind, char character) {
		if (ind < str.length()) {
			if (str.charAt(ind) == '0') {
				if (tree.left == null) 
					tree.left = new AVL();
					tree.left = addEntry(tree.left, str, ind + 1, character);
				} else {
					if (tree.right == null)
						tree.right = new AVL();
					tree.right = addEntry(tree.right, str, ind + 1, character);
				}
				return tree;
			} else {
				tree.character = character;
				return tree;
			}
		}
	}


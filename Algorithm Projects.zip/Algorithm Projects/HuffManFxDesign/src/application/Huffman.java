package application;

public class Huffman implements Comparable<Huffman> {
	char character;
	int number;
	String code;
	int length;

	public Huffman(char character, int number, String code, int length) {
		this.character = character;
		this.number = number;
		this.code = code;
		this.length = length;
	}

	public Huffman(char character) {
		this.character = character;
	}

	public Huffman(char character, int number) {
		this.character = character;
		this.number = number;
	}

	public char getCharacter() {
		return character;
	}

	public void setCharacter(char character) {
		this.character = character;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	@Override
	public String toString() {
		return "Huffman [ Character = " + (int) character + ", number =" + number + ", code =" + code + ", length ="
				+ length + "]";
	}

	@Override
	public int compareTo(Huffman o) {
		return code.compareTo(o.code);
	}

}

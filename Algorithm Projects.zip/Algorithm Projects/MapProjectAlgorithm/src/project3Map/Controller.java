package project3Map;

import project3Map.Edge;
import project3Map.Graph;
import project3Map.Vertex;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class Controller {
	// Data fields
	@FXML
	private TextField infoBar;

	@FXML
	private AnchorPane anchorPane;

	@FXML
	private ImageView map;

	@FXML
	private ImageView logo;
	@FXML
	private ComboBox<String> from;

	@FXML
	private ComboBox<String> to;

	@FXML
	private Button find;

	@FXML
	private TextField distance;

	@FXML
	private Button resetUI;

	@FXML
	private Button switchVals;

	@FXML
	private TableView<ObservableList> sPtable;

	@FXML
	private RadioButton dijAlgo;

	@FXML
	private RadioButton UCSAlgo;

	private boolean isClickedTwice = false;
	private Circle outerCircle = new Circle();
	private Graph graph = new Graph();
	private String shortestPath;
	private boolean switchClicked;
	private ObservableList<ObservableList> data;
	ToggleGroup algos = new ToggleGroup();
	Color srcColorVal = Color.GREEN, distColorVal = Color.DARKBLUE, midColorVal = Color.YELLOW,
			lineColorVal = Color.RED;

	// A method to initialize the UI objects
	public void initialize() {

		dijAlgo.setToggleGroup(algos);
		dijAlgo.setSelected(true);
		dijAlgo.setUserData("Dijkstra's Algorithm");
		UCSAlgo.setToggleGroup(algos);
		UCSAlgo.setSelected(false);
		UCSAlgo.setUserData("Reset");

		initialize_table();

		find.setDisable(false);

		readData();

		anchorPane.setPickOnBounds(true);

		fillComboBox();

		from.setEditable(true);

		to.setEditable(true);

		// if the mouse was moved inside the imageView
		anchorPane.setOnMouseMoved(e -> {
			Vertex hoveredOn = graph.findVertexByCoos(e.getX(), e.getY());
//----------------------------------------------------------------------------------------------------------------------------------
			if (hoveredOn == null) {
				infoBar.setText("");

				return;
			}

			infoBar.setText(hoveredOn.getName());
		});

		// if the mouse was clicked on a point inside the imageView
		anchorPane.setOnMouseClicked(e -> {

			Vertex clicked = graph.findVertexByCoos(e.getX(), e.getY());

			if (clicked == null) {

				infoBar.setText("Choose an exisiting city!");

				Platform.runLater(() -> {
					Alert alert = new Alert(Alert.AlertType.ERROR);

					Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
					// stage.getIcons().add(new Image("Resources/Images/MapIcon.png"));

					alert.setTitle("Error");
					alert.setHeaderText("no such city!!");
					alert.setContentText("Choose a valid city please.");
					alert.show();
				});

				return;

			}
			if (isClickedTwice) {
				shortestPath = null;

				to.getSelectionModel().select(clicked.getName());

				isClickedTwice = false;

				Vertex from = graph.findVertexByCoos(outerCircle.getCenterX(), outerCircle.getCenterY());
				Vertex to = graph.findVertexByCoos(e.getX(), e.getY());

				if (from.getName() == to.getName()) {
					infoBar.setText("Choose two different cities !");

					Platform.runLater(() -> {
						Alert alert = new Alert(Alert.AlertType.ERROR);

						Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
						stage.getIcons().add(new Image("Resources/Images/MapIcon.png"));

						alert.setTitle("Error");
						alert.setHeaderText("!");
						alert.setContentText("Choose two different cities please.");
						alert.show();
					});

					this.from.getSelectionModel().clearSelection();
					this.to.getSelectionModel().clearSelection();

					anchorPane.getChildren().clear();

					sPtable.getItems().clear();
					distance.clear();

					return;
				}

				Vertex res = null;

				res = graph.getShortestPath(from, to);

				if (res == null) {

					Platform.runLater(() -> {
						Alert alert = new Alert(Alert.AlertType.WARNING);

						Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();

						alert.setTitle("Warning");
						alert.setHeaderText("Failure!");
						alert.setContentText(
								"No path was found from \"" + from.getName() + "\" to \"" + to.getName() + "\".");
						alert.show();
					});

					this.from.getSelectionModel().clearSelection();
					this.to.getSelectionModel().clearSelection();

					anchorPane.getChildren().clear();
					sPtable.getItems().clear();
					distance.clear();

					return;
				}

				LinkedList<String> resStr = resStr = graph.shortestPathString(res);
				LinkedList<Vertex> resVercs = graph.shortestPathVertices(res);

				shortestPath = "From \"" + from.getName() + "\" to \"" + to.getName() + "\":"
						+ System.getProperty("line.separator") + System.getProperty("line.separator");

				Double dist = 0.0;

				for (String p : resStr) {
					dist += Double.parseDouble(p.substring(p.lastIndexOf(" : ") + 2, p.indexOf(" km")));

					shortestPath += p + System.getProperty("line.separator");
				}

				NumberFormat nf = NumberFormat.getInstance();
				nf.setMaximumFractionDigits(3);

				distance.setText(nf.format(dist) + " km");

				fillDestTable();

				ArrayList<Circle> circles = new ArrayList<>();
				ArrayList<Line> lines = new ArrayList<>();

				for (int i = 0; i < resVercs.size(); i++) {
					if (i == 0) {
						Line line = new Line();

						line.setStartX(outerCircle.getCenterX());
						line.setStartY(outerCircle.getCenterY());
						line.setEndX(resVercs.get(i).getxCo());
						line.setEndY(resVercs.get(i).getyCo());
						line.setStroke(lineColorVal);
						line.setStrokeWidth(2);

						Circle circle = new Circle();

						circle.setCenterX(resVercs.get(i).getxCo());
						circle.setCenterY(resVercs.get(i).getyCo());
						circle.setRadius(5);

						if (resVercs.get(i).getType().toLowerCase().matches("Major".toLowerCase()))
							circle.setRadius(5);
						else
							circle.setRadius(4);

						if (resVercs.size() != i + 1)
							circle.setFill(midColorVal);
						else
							circle.setFill(distColorVal);

						circle.setStroke(Color.BLACK);

						lines.add(line);
						circles.add(circle);
						circles.add(outerCircle);
					} else {
						Line line = new Line();

						line.setStartX(resVercs.get(i - 1).getxCo());
						line.setStartY(resVercs.get(i - 1).getyCo());
						line.setEndX(resVercs.get(i).getxCo());
						line.setEndY(resVercs.get(i).getyCo());
						line.setStroke(lineColorVal);
						line.setStrokeWidth(2);

						Circle circle = new Circle();

						circle.setCenterX(resVercs.get(i).getxCo());
						circle.setCenterY(resVercs.get(i).getyCo());
						circle.setRadius(5);

						if (resVercs.get(i).getType().toLowerCase().matches("Major".toLowerCase()))
							circle.setRadius(5);
						else
							circle.setRadius(4);

						if (resVercs.size() != i + 1)
							circle.setFill(midColorVal);
						else
							circle.setFill(distColorVal);

						circle.setStroke(Color.BLACK);

						lines.add(line);
						circles.add(circle);
					}
				}

				anchorPane.getChildren().clear();

				for (int i = 0; i < lines.size(); i++)
					anchorPane.getChildren().add(lines.get(i));
				for (int i = 0; i < circles.size(); i++)
					anchorPane.getChildren().add(circles.get(i));

				infoBar.setText("Path was found successfully!");
			} else {
				from.getSelectionModel().clearSelection();
				from.getEditor().clear();
				to.getSelectionModel().clearSelection();
				to.getEditor().clear();

				shortestPath = null;

				outerCircle.setCenterX(clicked.getxCo());
				outerCircle.setCenterY(clicked.getyCo());
				outerCircle.setRadius(5);
				outerCircle.setFill(srcColorVal);
				outerCircle.setStroke(Color.BLACK);
				anchorPane.getChildren().clear();
				anchorPane.getChildren().add(outerCircle);

				isClickedTwice = true;

				if (/* mirror.isSelected() && */ to.getSelectionModel().getSelectedItem() != null
						&& to.getSelectionModel().getSelectedItem() != ""
						&& (from.getSelectionModel().getSelectedItem() == null
								|| from.getSelectionModel().getSelectedItem() == ""))
					from.getSelectionModel().select(
							graph.findVertexByCoos(outerCircle.getCenterX(), outerCircle.getCenterY()).getName());
				else {
					to.getSelectionModel().clearSelection();
					from.getSelectionModel().select(
							graph.findVertexByCoos(outerCircle.getCenterX(), outerCircle.getCenterY()).getName());

					distance.clear();
					sPtable.getItems().clear();
					infoBar.setText("");
				}
			}
		});
	}

	// Draw the graph on the map
	@FXML
	void drawGraph(ActionEvent event) {
		// resetUI(new ActionEvent());

		for (Edge e : graph.getEdges()) {
			Line line = new Line();
			line.setStartX(e.getFrom().getxCo());
			line.setStartY(e.getFrom().getyCo());
			line.setEndX(e.getTo().getxCo());
			line.setEndY(e.getTo().getyCo());
			line.setStrokeWidth(2);

			if (graph.findEdge(e.getTo(), e.getFrom()) != null)
				line.setStroke(Color.YELLOW);
			else
				line.setStroke(Color.BLUE);

			anchorPane.getChildren().addAll(line);
		}

		for (Vertex v : graph.getVertices()) {
			Circle circle = new Circle();

			circle.setCenterX(v.getxCo());
			circle.setCenterY(v.getyCo());

			if (v.getType().toLowerCase().matches("Major".toLowerCase())) {

				circle.setFill(Color.RED);
				circle.setRadius(5);
			} else {
				circle.setFill(Color.GREENYELLOW);
				circle.setRadius(4);
			}

			circle.setStroke(Color.BLACK);

			anchorPane.getChildren().add(circle);
		}

		infoBar.setText("Vertices = " + graph.getVertices().size() + " ~~ Edges = " + graph.getEdges().size());

	}

	// Switch "From" with "To"
	@FXML
	void switchVals(ActionEvent event) {
		anchorPane.getChildren().clear();

		distance.clear();
		sPtable.getItems().clear();
		shortestPath = null;
		switchClicked = true;

		String swapFrom = from.getSelectionModel().getSelectedItem();
		String swapTo = to.getSelectionModel().getSelectedItem();

		to.getSelectionModel().clearSelection();
		from.getSelectionModel().clearSelection();

		to.getSelectionModel().select(swapFrom);
		from.getSelectionModel().select(swapTo);

	}

	void printadj() {

	}

	@FXML
	public void shortestPath() {
		if (from.getSelectionModel().getSelectedItem() == null || to.getSelectionModel().getSelectedItem() == null) {
			infoBar.setText("Choose both From and To destinations please!");

			// Generating an alert
			Platform.runLater(() -> {
				Alert alert = new Alert(Alert.AlertType.ERROR);

				Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();

				alert.setTitle("Error");
				alert.setHeaderText("wrong input!");
				alert.setContentText("Choose both From and To destinations please.");
				alert.show();
			});

			return;
		}

		if (graph.findVertexByName(from.getEditor().getText()) == null
				|| graph.findVertexByName(from.getSelectionModel().getSelectedItem()) == null) {
			Alert alert = new Alert(Alert.AlertType.ERROR);

			Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();

			alert.setTitle("ERROR");
			alert.setHeaderText("Failure!");
			alert.setContentText("Location \"" + from.getSelectionModel().getSelectedItem() + "\" is not available!");
			alert.show();

			from.getEditor().clear();
			anchorPane.getChildren().clear();
			from.getSelectionModel().clearSelection();
			distance.clear();
			sPtable.getItems().clear();
			shortestPath = null;
//			time.clear();

			return;
		} else if (graph.findVertexByName(to.getEditor().getText()) == null
				|| graph.findVertexByName(to.getSelectionModel().getSelectedItem()) == null) {
			Alert alert = new Alert(Alert.AlertType.ERROR);

			Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
			// stage.getIcons().add(new Image("Resources/Images/MapIcon.png"));

			alert.setTitle("ERROR");
			alert.setHeaderText("Failure!");
			alert.setContentText("Location \"" + to.getSelectionModel().getSelectedItem() + "\" is not available!");
			alert.show();

			to.getEditor().clear();
			anchorPane.getChildren().clear();
			to.getSelectionModel().clearSelection();
			distance.clear();
			sPtable.getItems().clear();
			shortestPath = null;
//			time.clear();

			return;
		}

		isClickedTwice = false;

		shortestPath = null;

		if (from.getSelectionModel().getSelectedItem() == "" || from.getSelectionModel().getSelectedItem() == null
				|| to.getSelectionModel().getSelectedItem() == "" || to.getSelectionModel().getSelectedItem() == null) {
			distance.clear();
			sPtable.getItems().clear();

			infoBar.setText("Choose both From and To destinations please!");

			// Generating an alert
			Platform.runLater(() -> {
				Alert alert = new Alert(Alert.AlertType.ERROR);

				Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
				// stage.getIcons().add(new Image("Resources/Images/MapIcon.png"));

				alert.setTitle("Error");
				alert.setHeaderText("Failure!");
				alert.setContentText("Choose both From and To destinations please.");
				alert.show();
			});

			return;
		}

		anchorPane.getChildren().clear();

		Vertex fromV = graph.findVertexByName(from.getSelectionModel().getSelectedItem());
		Vertex toV = graph.findVertexByName(to.getSelectionModel().getSelectedItem());

		try {
			if (fromV.getName() == toV.getName()) {
				infoBar.setText("Choose two different locations please!");

				Platform.runLater(() -> {
					Alert alert = new Alert(Alert.AlertType.ERROR);

					Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
					alert.setTitle("Error");
					alert.setHeaderText("Failure!");
					alert.setContentText("Choose two different locations please.");
					alert.show();
				});

				this.from.getSelectionModel().clearSelection();
				this.to.getSelectionModel().clearSelection();

				anchorPane.getChildren().clear();
				from.getSelectionModel().clearSelection();
				to.getSelectionModel().clearSelection();
				sPtable.getItems().clear();
				distance.clear();

				return;
			}
		} catch (NullPointerException ex) {
			return;
		}

		Vertex res = null;

		if (algos.getSelectedToggle().getUserData().toString().matches("Dijkstra's Algorithm")) {
			long startTime = System.nanoTime();

			res = graph.getShortestPath(fromV, toV);
			System.out.println("Cost of Dijkstra Algorithm is: " + String.valueOf(graph.dijCost));
			System.out.println("dij " + res.getAdjacentCities().getLast().getName());
			System.out.println("di");

		} else if (algos.getSelectedToggle().getUserData().toString().matches("BFS")) {

		} // ======================================
		else if (algos.getSelectedToggle().getUserData().toString().matches("a")) {
			long startTime = System.nanoTime();

			System.out.println("a reached");
		} // ======================================
		else if (algos.getSelectedToggle().getUserData().toString().matches("UCS Algorithm")) {
			long startTime = System.nanoTime();
			res = null;
			System.out.println("ucs " + res.getAdjacentCities().getLast().getName());

		} // ======================================

		if (res == null) {
			infoBar.setText("No path!");

			Platform.runLater(() -> {
				Alert alert = new Alert(Alert.AlertType.WARNING);

				Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
				alert.setTitle("Warning");
				alert.setHeaderText("Failure!");
				alert.setContentText(
						"No path was found from \"" + fromV.getName() + "\" to \"" + toV.getName() + "\".");
				alert.show();
			});

			anchorPane.getChildren().clear();
			from.getSelectionModel().clearSelection();
			to.getSelectionModel().clearSelection();
			sPtable.getItems().clear();
			distance.clear();

			return;
		}

		LinkedList<String> resStr = graph.shortestPathString(res);
		LinkedList<Vertex> pathVertices = graph.shortestPathVertices(res);
		System.out.println(resStr);
		shortestPath = "From \"" + fromV.getName() + "\" to \"" + toV.getName() + "\":"
				+ System.getProperty("line.separator") + System.getProperty("line.separator");

		Double dist = 0.0;

		for (String p : resStr) {
			dist += Double.parseDouble(p.substring(p.lastIndexOf(" : ") + 2, p.indexOf(" km")));

			shortestPath += p + System.getProperty("line.separator");
		}

		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(3);

		distance.setText(nf.format(dist) + " km");

		fillDestTable();

		ArrayList<Circle> circles = new ArrayList<>();
		ArrayList<Line> lines = new ArrayList<>();

		for (int i = 0; i < pathVertices.size(); i++) {
			if (i == 0) {
				Circle initCircle = new Circle();
				initCircle.setCenterX(fromV.getxCo());
				initCircle.setCenterY(fromV.getyCo());

				if (fromV.getType().toLowerCase().matches("Major".toLowerCase()))
					initCircle.setRadius(5);
				else
					initCircle.setRadius(4);

				initCircle.setFill(srcColorVal);
				initCircle.setStroke(Color.BLACK);

				Line line = new Line();

				line.setStartX(fromV.getxCo());
				line.setStartY(fromV.getyCo());
				line.setEndX(pathVertices.get(i).getxCo());
				line.setEndY(pathVertices.get(i).getyCo());
				line.setStroke(lineColorVal);
				line.setStrokeWidth(2);

				Circle circle = new Circle();

				circle.setCenterX(pathVertices.get(i).getxCo());
				circle.setCenterY(pathVertices.get(i).getyCo());

				if (pathVertices.get(i).getType().toLowerCase().matches("Major".toLowerCase()))
					circle.setRadius(5);
				else
					circle.setRadius(4);

				if (pathVertices.size() != i + 1)
					circle.setFill(midColorVal);
				else
					circle.setFill(distColorVal);

				circle.setStroke(Color.BLACK);

				circles.add(circle);
				circles.add(initCircle);
				lines.add(line);
			} else {
				Line line = new Line();

				line.setStartX(pathVertices.get(i - 1).getxCo());
				line.setStartY(pathVertices.get(i - 1).getyCo());
				line.setEndX(pathVertices.get(i).getxCo());
				line.setEndY(pathVertices.get(i).getyCo());
				line.setStroke(lineColorVal);
				line.setStrokeWidth(2);

				Circle circle = new Circle();

				circle.setCenterX(pathVertices.get(i).getxCo());
				circle.setCenterY(pathVertices.get(i).getyCo());

				if (pathVertices.get(i).getType().toLowerCase().matches("Major".toLowerCase()))
					circle.setRadius(5);
				else
					circle.setRadius(4);

				if (pathVertices.size() != i + 1) {
					if (algos.getSelectedToggle().getUserData().toString().matches("Dijkstra's Algorithm")) {
						circle.setFill(Color.ALICEBLUE);
						line.setStroke(Color.GREEN);
					} else if (algos.getSelectedToggle().getUserData().toString().matches("A* Search Algorithm")) {
						circle.setFill(Color.GREEN);
						line.setStroke(Color.ALICEBLUE);
					} else if (algos.getSelectedToggle().getUserData().toString().matches("UCS Algorithm")) {
						circle.setFill(Color.RED);
						line.setStroke(Color.YELLOW);
					} else if (algos.getSelectedToggle().getUserData().toString().matches("BFS Algorithm")) {
						circle.setFill(Color.YELLOW);
						line.setStroke(Color.RED);
					}
				} else
					circle.setFill(distColorVal);

				circle.setStroke(Color.BLACK);

				circles.add(circle);
				lines.add(line);
			}
		}

		anchorPane.getChildren().clear();

		for (int i = 0; i < lines.size(); i++)
			anchorPane.getChildren().add(lines.get(i));
		for (int i = 0; i < circles.size(); i++)
			anchorPane.getChildren().add(circles.get(i));

		infoBar.setText("Path was found successfully!");
	}

	// initialize the choice boxes
	private void fillComboBox() {
		ObservableList<String> choices = FXCollections.observableArrayList();

		for (Vertex city : graph.getVertices())
			choices.add(city.getName());

		Collections.sort(choices, String.CASE_INSENSITIVE_ORDER);

		from.setItems(choices);
		to.setItems(choices);
	}

	@FXML
	void resetUI(ActionEvent event) {
		readData();

		anchorPane.getChildren().clear();

		from.getSelectionModel().clearSelection();
		to.getSelectionModel().clearSelection();
		distance.clear();
		sPtable.getItems().clear();
		shortestPath = null;

		isClickedTwice = false;

		from.getEditor().clear();
		to.getEditor().clear();

		infoBar.setText("UI and Data have been reset!");
	}

	// to read the file
	private void readData() {
		File file = new File("src/project3Map/Palestine_Map.txt");
		Scanner input = null;
		String str = null;

		try {
			input = new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return;
		}

		Vertex fromV = null;

		graph.getEdges().clear();
		graph.getVertices().clear();
		anchorPane.getChildren().clear();

		while (input.hasNextLine()) {

			str = input.nextLine();

			if (str.matches(""))
				continue;

			String[] parts = str.split(": ");

			if (parts.length == 4) {
				fromV = new Vertex(parts[1], Double.parseDouble(parts[2]), Double.parseDouble(parts[3]), parts[0]);
				// fromV.setType(parts[0]);
			} else {
				Vertex toV = new Vertex(parts[1], Double.parseDouble(parts[2]), Double.parseDouble(parts[3]), parts[0]);

				graph.addData(fromV, toV, Double.parseDouble(parts[4]));
				graph.addData(toV, fromV, Double.parseDouble(parts[4]));

			}

		}

		input.close();
	}

	// Initialize the table with the appropriate columns
	private void initialize_table() {
		TableColumn<ObservableList, String> num = new TableColumn<>("#city");
		num.setMinWidth(10);
		num.setMaxWidth(50);
		num.setCellValueFactory(param -> new SimpleStringProperty(param.getValue().get(0).toString()));
		num.setSortable(false);
		num.setStyle("-fx-background-color: DarkOliveGreen;-fx-border-color: black");

		TableColumn<ObservableList, String> source = new TableColumn<>("From");
		source.setMinWidth(106);
		source.setCellValueFactory(param -> new SimpleStringProperty(param.getValue().get(1).toString()));
		source.setSortable(false);
		source.setStyle("-fx-background-color: DarkOliveGreen;-fx-border-color: black");

		TableColumn<ObservableList, String> destination = new TableColumn<>("To");
		destination.setMinWidth(106);
		destination.setCellValueFactory(param -> new SimpleStringProperty(param.getValue().get(2).toString()));
		destination.setSortable(false);
		destination.setStyle("-fx-background-color: DarkOliveGreen;-fx-border-color: black");

		TableColumn<ObservableList, String> distance = new TableColumn<>("Distance");
		distance.setMinWidth(40);
		distance.setCellValueFactory(param -> new SimpleStringProperty(param.getValue().get(3).toString()));
		distance.setSortable(false);
		distance.setStyle("-fx-background-color: DarkOliveGreen;-fx-border-color: black");

		sPtable.getColumns().addAll(num, source, destination, distance);
	}

	// to display the SP in the table
	public void fillDestTable() {
		data = FXCollections.observableArrayList();
		ObservableList<String> row = null;

		String[] inits = shortestPath.split("[\n]+");

		for (int i = 2; i < inits.length; i++) {
			String[] show = inits[i].split("[>:]+");

			row = FXCollections.observableArrayList();

			row.add((i - 1) + "");
			row.add(show[0].trim());
			row.add(show[1].trim());
			row.add(show[2].trim());

			data.add(row);
		}

		sPtable.getItems().clear();
		sPtable.setItems(data);
	}

	// Closing the application
	public void close() {
		// mirror.getScene().getWindow().hide();
	}
}

package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Open File");
			fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.txt"),
					new ExtensionFilter("Java Files", "*.java"),
					new ExtensionFilter("Web Files", "*.html", "*.css", "*.js", "*.php"),
					new ExtensionFilter("All Files", "*.*"));

			Text headerText = new Text("Huffman System");
			headerText.setY(45);
			headerText.setX(130);
			headerText.setFont(new Font("Cambira", 46));
			headerText.setFill(Color.DARKOLIVEGREEN);
			headerText.setStrokeWidth(1);
			headerText.setStroke(Color.BLACK);
			RadioButton compress = new RadioButton("Compress File");
			compress.setTranslateX(240);
			compress.setTranslateY(80);
			RadioButton uncompress = new RadioButton("Uncompress File");
			uncompress.setTranslateX(240);
			uncompress.setTranslateY(120);

			ToggleGroup radioGroup = new ToggleGroup();
			compress.setToggleGroup(radioGroup);
			uncompress.setToggleGroup(radioGroup);
			compress.setUserData("Compress File");
			uncompress.setUserData("Uncompress File");

			Button button = new Button("SELECT");
			button.setTranslateX(265);
			button.setTranslateY(150);

//			Label result = new Label();

			Pane root = new Pane();
			root.setStyle("-fx-background-color: lemonChiffon");
			root.getChildren().addAll(headerText, compress, uncompress, button);
			Scene scene = new Scene(root, 600, 400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("Huffman System");
			primaryStage.show();
			button.setOnAction((ActionEvent) -> {
				File selectedFile = fileChooser.showOpenDialog(primaryStage);
				if(selectedFile != null) {
					String filePath = selectedFile.getPath();
					try {
						BufferedReader br = new BufferedReader(new FileReader(filePath));
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					String line = "";
					String text = "";
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}

package project3Map;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;



public class Main extends Application
{
	@Override
	public void start(Stage stage) throws Exception
	{
		Parent root = FXMLLoader.load(getClass().getResource("Map.fxml"));

		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Best Path System");
		stage.setResizable(false);
		stage.show();
	}

	public static void main(String[] args)
	{
		launch(args);
	}
}




public class ReadFile {
	
	private int[] data = {1,2,3,4,5,6,7,8,9};
	
	public ReadFile(int[] data, String line) {
		this.setData(data);
		line.replace(" ", "");
		
	}

	public ReadFile() {
		// TODO Auto-generated constructor stub
	}

	public int[] getData() {
		return data;
	}

	public void setData(int[] data) {
		this.data = data;
	}
//	@Override
//	public boolean equals(Object object) {
//		if (object instanceof TRecord) {
//			return seatNumber == ((TRecord) object).seatNumber;
//		}
//		return false;
//	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

}

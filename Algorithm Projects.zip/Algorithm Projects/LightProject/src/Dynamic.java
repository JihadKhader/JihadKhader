import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Dynamic {
	static int c[][];
	static int[] num1;
	static int[] num2;

	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("Hello");
//		int[] a = { 2, 6, 3, 5, 4, 1 };
//		int[] test = {};
		File file = new File("C:/Users/DELL/Desktop/Algo.txt");
		Scanner sc = new Scanner(file);
		String str = sc.nextLine();
		String str1 = sc.nextLine();
		int length = Integer.parseInt(str) + 1;
		num1 = new int[length];
		for (int i = 0; i < num1.length; i++) {
			num1[i] = i;
		}
		String[] strArray = str1.split(" ");
		num2 = new int[strArray.length + 1];
		num2[0] = 0;
		for (int i = 1; i < num2.length; i++) {
			num2[i] = Integer.parseInt(strArray[i - 1]);
		}
		System.out.println(longesCommonSub());
		sc.close();
	}

	public static String printLCS(int[] array1, int[] array2, int[][] arr1, int x, int y) {

		String print = "";
		for (int i = 0; i < y; i++) {
			print += ("\t" + array2[i]);
		}
		print += "\n";
		print += "------------------------------------------------------------------------\n";
		for (int i = 0; i < x; i++) {

			print += (array1[i] + "|\t ");
			for (int j = 0; j < y; j++) {
				print += (arr1[i][j] + "\t");
			}
			print += "\n";

		}
		return "LCS: " + print;

	}

	public static String longesCommonSub() {

		int m = num1.length;
		int n = num2.length;
		c = new int[m + 1][n + 1];
		for (int i = 0; i < m; i++) {
			c[i][0] = 0;
		}
		for (int j = 0; j < n; j++) {
			c[0][j] = 0;
		}
		//int[][] arr = new int[m + 1][n + 1];
		for (int i = 1; i < m; i++) {
			for (int j = 1; j < n; j++) {
				if (num1[i] == num2[j]) {
					c[i][j] = c[i - 1][j - 1] + 1;
//					System.out.println("test");
				} else {
					c[i][j] = Math.max(c[i - 1][j], c[i][j - 1]);
				}
			}
			
		}
		System.out.println(printLCS(num1 , num2 , c , m , n));
		return "LCS:" + c[n - 1][m - 1];

	}

}

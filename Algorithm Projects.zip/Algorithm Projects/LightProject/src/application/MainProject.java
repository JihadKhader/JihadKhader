package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.stage.Stage;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;

public class MainProject extends Application {

	@Override
	public void start(Stage stage) {

		AnchorPane root = new AnchorPane();
		HBox bb = new HBox();

		Button button1 = new Button("Button 1");
		Button button2 = new Button("Button 2");
		Button button3 = new Button("Button 3");
		ScrollPane scroll1 = new ScrollPane();
		scroll1.setFitToHeight(true);
		Text text = new Text("123");
//        scroll1.setFitToWidth(true);
		for (int i = 0; i <= 10; i++) {
			Circle circle = new Circle();
			circle.setCenterX(300 + (i * 80));
			circle.setCenterY(275);
			circle.setRadius(20);
			circle.setFill(Color.PINK);
			circle.setStroke(Color.BLACK);
			bb.getChildren().addAll(circle);
		}
		scroll1.setContent(bb);
		AnchorPane.setTopAnchor(button1, 30.0);
		AnchorPane.setRightAnchor(button1, 30.0);
		AnchorPane.setLeftAnchor(button1, 30.0);

		button1.setPrefHeight(30);

		AnchorPane.setTopAnchor(button2, 70.0);
		AnchorPane.setRightAnchor(button2, 130.0);
		AnchorPane.setLeftAnchor(button2, 30.0);
		AnchorPane.setBottomAnchor(button2, 30.0);

		AnchorPane.setTopAnchor(button3, 70.0);
		AnchorPane.setRightAnchor(button3, 30.0);
		AnchorPane.setBottomAnchor(button3, 30.0);

		button3.setPrefWidth(80);
		StackPane stack = new StackPane();
		stack.getChildren().addAll(scroll1, text);
		root.getChildren().addAll(button1, button2, button3, scroll1, text);

		Scene scene = new Scene(root, 350, 250);

		stage.setTitle("JavaFX AnchorPane");

		stage.setScene(scene);

		stage.show();

	}

	public static void main(String[] args) {
		launch(args);
	}

}

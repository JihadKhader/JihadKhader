package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class Scroll extends Application {

	@Override
	public void start(Stage stage) {
		
//		Stage main  =  new Stage();
//		main.setWidth(arg0);
		
		// في النافذة Root Node و الذي ننوي جعله الـ ScrollPane هنا قمنا بإنشاء كائن من
		// الكلاس
		ScrollPane root = new ScrollPane();
		
		// root يمثل الزر الذي سنضعه بداخل الكائن Button هنا قمنا بإنشاء كائن من الكلاس
		Button button = new Button("Button");
		button.setMaxHeight(Double.MAX_VALUE);
		button.setMaxWidth(Double.MAX_VALUE);
//		button.setPrefSize(300, 200);

		// root في الكائن button هنا قمنا بإضافة الكائن
		root.setContent(button);

		// فيها و تحديد حجمها Node كأول root هنا قمنا بإنشاء محتوى النافذة مع تعيين
		
		VBox main =  new VBox();
		VBox.setVgrow(button, Priority.ALWAYS);
		
		Scene scene = new Scene(main, 850, 450);
		
		// هنا وضعنا عنوان للنافذة
		stage.setTitle("JavaFX ScrollPane");

		// أي وضعنا محتوى النافذة الذي قمنا بإنشائه للنافذة .stage في كائن الـ scene هنا
		// وضعنا كائن الـ
		stage.setScene(scene);

		// هنا قمنا بإظهار النافذة
		stage.show();

	}

	// هنا قمنا بتشغيل التطبيق
	public static void main(String[] args) {
		launch(args);
	}

}

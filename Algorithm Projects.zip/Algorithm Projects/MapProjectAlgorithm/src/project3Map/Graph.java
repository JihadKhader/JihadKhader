package project3Map;

import java.util.*;

public class Graph {
	LinkedList<Edge> edges = new LinkedList<>();
	LinkedList<Vertex> vertices = new LinkedList<>();

	// add data to the graph
	public void addData(Vertex from, Vertex to, double cost) {
		Vertex fromCity = findVertex(from);
		Vertex toCity = findVertex(to);

		if (fromCity == null) {
			fromCity = from;
			vertices.addFirst(fromCity);
		}
		if (toCity == null) {
			toCity = to;
			vertices.addFirst(toCity);
		}

		edges.addFirst(new Edge(fromCity, toCity, cost));
	}

	// method Vertex findVertex it checks a vertex v
	Vertex findVertex(Vertex v) {
		for (int i = 0; i < vertices.size(); i++)
			if (v.getName().toLowerCase().matches(vertices.get(i).getName().toLowerCase())
					&& v.getxCo() == vertices.get(i).getxCo() && v.getyCo() == vertices.get(i).getyCo()
					&& v.getType().toLowerCase().matches(vertices.get(i).getType().toLowerCase()))
				return vertices.get(i);

		return null;
	}

	// method Vertex findVertexByName it checks the vertex from the string (name)
	public Vertex findVertexByName(String name) {
		for (int i = 0; i < vertices.size(); i++)
			if (name.toLowerCase().matches(vertices.get(i).getName().toLowerCase()))
				return vertices.get(i);

		return null;
	}

	// method vertex findVertexByCoos it checks if the vertex is found from its x,y
	// coordinates
	public Vertex findVertexByCoos(double x, double y) {
		for (int i = 0; i < edges.size(); i++) {
			if (aroundRadius((edges.get(i).getFrom().getxCo()), x)
					&& aroundRadius((edges.get(i).getFrom().getyCo()), y))
				return edges.get(i).getFrom();

			else if (aroundRadius((edges.get(i).getTo().getxCo()), x)
					&& aroundRadius((edges.get(i).getTo().getyCo()), y))
				return edges.get(i).getTo();
		}

		return null;
	}

	public boolean aroundRadius(double d, double x) {
		if (x <= d + 5 && x >= d - 5)
			return true;

		return false;
	}

	// method that find number of one ways
	public int findNumberOfOneWays() {
		int sum = 0;

		for (Edge e : edges)
			if (findEdge(e.getTo(), e.getFrom()) == null)
				sum++;

		return sum;
	}

	// method that searches for an Edge depending on the vertex u First and v Second
	public Edge findEdge(Vertex u, Vertex v) {
		for (int i = 0; i < edges.size(); i++)
			if ((u.getName().toLowerCase().matches(edges.get(i).getFrom().getName().toLowerCase())
					&& u.getxCo() == edges.get(i).getFrom().getxCo() && u.getyCo() == edges.get(i).getFrom().getyCo()
					&& u.getType().toLowerCase().matches(edges.get(i).getFrom().getType().toLowerCase()))
					&& (v.getName().toLowerCase().matches(edges.get(i).getTo().getName().toLowerCase())
							&& v.getxCo() == edges.get(i).getTo().getxCo()
							&& v.getyCo() == edges.get(i).getTo().getyCo()
							&& v.getType().toLowerCase().matches(edges.get(i).getTo().getType().toLowerCase())))
				return edges.get(i);

		return null;
	}

	// method that determines that the edge is found
	public boolean isFound(double x, double y) {
		for (int i = 0; i < edges.size(); i++)
			if ((aroundRadius((edges.get(i).getFrom().getxCo()), x)
					&& aroundRadius((edges.get(i).getFrom().getyCo()), y))
					|| (aroundRadius((edges.get(i).getTo().getxCo()), x)
							&& aroundRadius((edges.get(i).getTo().getyCo()), y)))
				return true;

		return false;
	}

	// Dijkstra Algorithm method that takes Vertex fromCity
	public void dijkstra(Vertex fromCity) {

		// linked list vertices
		for (Vertex v : vertices) {

			v.setDistance(Integer.MAX_VALUE);
			v.setPath(null);
		}

		Vertex fromLocal = findVertex(fromCity);
		fromLocal.setDistance(0);

		PriorityQueue<Vertex> heap = new PriorityQueue<>();
		heap.add(fromLocal);

		while (!heap.isEmpty()) {
			// .poll() method takes the first element [head]
			Vertex u = heap.poll();
			for (Vertex adjacent : u.getAdjacentCities()) {
				Edge e = findEdge(u, adjacent);
				double newDistance = u.getDistance() + e.getCost();

				if (newDistance < adjacent.getDistance()) {
					heap.remove(adjacent);
					adjacent.setDistance(newDistance);
					adjacent.setPath(u);
					heap.add(adjacent);
				}
			}
		}
	}

	// method that prints the path in the console
	public LinkedList<String> printPath(Vertex target) {
		LinkedList<String> path = new LinkedList<>();
		for (Vertex v = target; v.getPath() != null; v = v.getPath()) {
			path.add(v.getPath().getName() + " > " + v.getName() + " : " + findEdge(v.getPath(), v).getCost() + " km");
			System.out.println(
					v.getPath().getName() + " > " + v.getName() + " : " + findEdge(v.getPath(), v).getCost() + " km");
		}
		Collections.reverse(path);

		return path;

	}

	// method that prints the shortest path String
	public LinkedList<String> shortestPathString(Vertex target) {

		LinkedList<String> path = new LinkedList<>();
		for (Vertex v = target; v.getPath() != null; v = v.getPath()) {
			path.add(v.getPath().getName() + " > " + v.getName() + " : " + findEdge(v.getPath(), v).getCost() + " km");
			System.out.println(
					v.getPath().getName() + " > " + v.getName() + " : " + findEdge(v.getPath(), v).getCost() + " km");
		}
		Collections.reverse(path);

		return path;
	}

	// method that find the shortest path vertices
	public LinkedList<Vertex> shortestPathVertices(Vertex target) {
		LinkedList<Vertex> path = new LinkedList<>();

//		if (target.getDistance() == Integer.MAX_VALUE)
//			return null;

		for (Vertex v = target; v.getPath() != null; v = v.getPath())
			path.add(v);

		Collections.reverse(path);

		return path;
	}

	// method that get the shortest path start
	public Vertex getShortestPathStart(Vertex target) {
		if (target.getDistance() == Integer.MAX_VALUE)
			return null;

		return target;
	}

	// method that reset Distance
	private void resetDistances() {
		for (Vertex v : vertices) {
			v.setDistance(Integer.MAX_VALUE);
			v.setPath(null);
		}
	}

	// recursion method that gets the shortest Path for Dijkstra's algorithm
	public Vertex getShortestPath(Vertex from, Vertex to) {
		dijkstra(from);

		return getShortestPathStart(findVertex(to));
	}

	int acost = 0, UCScost = 0, dijCost = 0;

//	public void AstarSearch(Vertex source, Vertex goal) {
//		acost = 0;
//		Aspace = 0;
//		source.setPath(null);
//		goal.setPath(null);
//		source.fValue = 0;
//		Set<Vertex> explored = new HashSet<Vertex>();
//
//		PriorityQueue<Vertex> heap = new PriorityQueue<Vertex>(20, new Comparator<Vertex>() {
//			// override compare method
//			public int compare(Vertex i, Vertex j) {
//				if (i.fValue > j.fValue) {
//					return 1;
//				}
//
//				else if (i.fValue < j.fValue) {
//					return -1;
//				}
//
//				else {
//					return 0;
//				}
//			}
//
//		});
//
//		// cost from start
//		source.gValue = 0;
//
//		heap.add(source);
//
//		boolean found = false;
//
//		while ((!heap.isEmpty()) && (!found)) {
//			if (heap.size() > Aspace)
//				Aspace = heap.size();
//			// the node in having the lowest f score value
//			Vertex current = heap.poll();
//
//			explored.add(current);
//
//			// goal found
//			if (current.getName().toLowerCase().matches(goal.getName().toLowerCase())) {
//				found = true;
//				acost++;
//			}
//
//			// check every child of current node
//			for (Vertex child : current.getAdjacentCities()) {
//
//				Edge e = findEdge(child, current);
//
//				double h = heuristicFunc(child, goal);
//				double cost = e.getCost();
//				double temp_g_scores = current.gValue + cost;
//				double temp_f_scores = temp_g_scores + h;
//
//				// if child node has been evaluated and the newer f score is higher, skip
//				if ((explored.contains(child)) && (temp_f_scores >= child.fValue)) {
//					acost++;
//
//					continue;
//				}
//
//				// else if child node is not in queue or newer f_ core is lower
//				else if ((!heap.contains(child)) || (temp_f_scores < child.fValue)) {
//					acost++;
//					// child.setDistance(current.getDistance() + cost);
//					child.setPath(current);
//					// queue.add(child);
//					// child.parent = current;
//					child.gValue = temp_g_scores;
//					child.fValue = temp_f_scores;
//
//					if (heap.contains(child)) {
//						acost++;
//						heap.remove(child);
//					}
//
//					heap.add(child);
//
//				}
//
//			}
//
//		}
//		// return findVertex(goal);
//		// returnASpace(space);
//	}

	public double heuristicFunc(Vertex current, Vertex goal) {
		double h = 0;
		double x1 = current.getxCo();
		double x2 = goal.getxCo();
		double y1 = current.getyCo();
		double y2 = goal.getyCo();

		double deltaX = Math.abs(x1 - x2);
		double deltaY = Math.abs(y1 - y2);

		double xSqu = Math.pow(deltaX, 2);
		double ySqu = Math.pow(deltaY, 2);

		double sum = xSqu + ySqu;

		h = Math.sqrt(sum);

		return h;
	}

//	public void UCS(Vertex source, Vertex goal) {
//		UCScost = 0;
//		UCSspace = 0;
//		source.setPath(null);
//		goal.setPath(null);
//		source.setDistance(0);
//		PriorityQueue<Vertex> heap = new PriorityQueue<Vertex>(20, new Comparator<Vertex>() {
//
//			// override compare method
//			public int compare(Vertex i, Vertex j) {
//				if (i.getDistance() > j.getDistance()) {
//					return 1;
//				}
//
//				else if (i.getDistance() < j.getDistance()) {
//					return -1;
//				}
//
//				else {
//					return 0;
//				}
//			}
//		}
//
//		);
//
//		heap.add(source);
//
//		Set<Vertex> explored = new HashSet<Vertex>();
//		boolean found = false;
//
//		// while frontier is not empty
//		while (!heap.isEmpty() && (found == false)) {
//			UCScost++;
//			if (heap.size() > UCSspace)
//				UCSspace = heap.size();
//			Vertex current = heap.poll();
//			explored.add(current);
//
//			if (current.getName().matches(goal.getName())) {
//				UCScost++;
//				found = true;
//
//			}
//
//			for (Vertex child : current.getAdjacentCities()) {
//				UCScost++;
//
//				Edge e = findEdge(child, current);
//
//				double cost = e.getCost();
//				// child.setDistance(current.getDistance() + cost);
//
//				if (!explored.contains(child) && !heap.contains(child)) {
//					UCScost++;
//
//					child.setDistance(cost + current.getDistance());
//					child.setPath(current);
//					heap.add(child);
//
//				} else if ((heap.contains(child)) && (child.getDistance() > (current.getDistance() + cost))) {
//					UCScost++;
//					child.setPath(current);
//
//					child.setDistance(current.getDistance() + cost);
//					// the next two calls decrease the key of the node in the queue
//
//					heap.remove(child);
//					heap.add(child);
//				}
//
//			}
//		}
////        }while(!queue.isEmpty()&&(found==false));
//
////return findVertex(goal);
//
////			
////			source.setDistance(0);
////			PriorityQueue<Vertex> queue = new PriorityQueue<Vertex>(20, new Comparator<Vertex>() {
////
////				// override compare method
////				public int compare(Vertex i, Vertex j) {
////					if (i.getDistance() > j.getDistance()) {
////						return 1;
////					}
////
////					else if (i.getDistance() < j.getDistance()) {
////						return -1;
////					}
////
////					else {
////						return 0;
////					}
////				}
////			}
////
////			);
////
////			queue.add(source);
////
////			Set<Vertex> explored = new HashSet<Vertex>();
////			boolean found = false;
////
////			// while frontier is not empty
////			do {
////
////				Vertex current = queue.poll();
////				explored.add(current);
////
////				if (current.getName().toLowerCase().matches(goal.getName().toLowerCase())) {
////					found = true;
////
////				}
////
////				for (Vertex child : current.getAdjacentCities()) {
////
////					Edge e = findEdge(child, current);
////
////					double cost = e.getCost();
////					child.setDistance(cost+current.getDistance());
////
////					if (!explored.contains(child) && !queue.contains(child)) {
////						child.setPath(current);
////						//child.setDistance(current.getDistance() + cost);
////						
////						queue.add(child);
////
////					} else if ((queue.contains(child)) && (child.getDistance() > (current.getDistance() ))) {
////						child.setPath(current);
////						//child.setDistance(current.getDistance() + cost);
////						// the next two calls decrease the key of the node in the queue
////						queue.remove(child);
////						queue.add(child);
////					}
////
////				}
////			} while (!queue.isEmpty() /*&& (found = false)*/);
//
////		source.setDistance(0);
////		PriorityQueue<Vertex> queue = new PriorityQueue<Vertex>(20, new Comparator<Vertex>() {
////
////			// override compare method
////			public int compare(Vertex i, Vertex j) {
////				if (i.getDistance() > j.getDistance()) {
////					return 1;
////				}
////
////				else if (i.getDistance() < j.getDistance()) {
////					return -1;
////				}
////
////				else {
////					return 0;
////				}
////			}
////		}
////
////		);
////
////		queue.add(source);
////
////		Set<Vertex> explored = new HashSet<Vertex>();
////		boolean found = false;
////
////		// while frontier is not empty
////		do {
////
////			Vertex current = queue.poll();
////			explored.add(current);
////
////			if (current.getName().toLowerCase().matches(goal.getName().toLowerCase())) {
////				found = true;
////
////			}
////
////			for (Vertex child : current.getAdjacentCities()) {
////
////				Edge e = findEdge(child, current);
////
////				double cost = e.getCost();
////				child.setDistance(cost+current.getDistance());
////
////				if (!explored.contains(child) && !queue.contains(child)) {
////					
////					child.setDistance(current.getDistance() + e.getCost());
////					child.setPath(current);
////					queue.add(child);
////
////				}
////				
////				else if ((queue.contains(child)) && (child.getDistance() > (current.getDistance() + e.getCost()))) {
////					child.setPath(current);
////					child.setDistance(current.getDistance() + e.getCost());
////					// the next two calls decrease the key of the node in the queue
////					queue.remove(child);
////					queue.add(child);
////				}
////
////			}
////		} while (!queue.isEmpty() && (found == false));
////System.out.println("in");
//
//		// return findVertex(goal);
//////
//		// return null;
////		source.setDistance(0);;
////        PriorityQueue<Vertex> queue = new PriorityQueue<Vertex>(20,
////            new Comparator<Vertex>(){
////
////                //override compare method
////                public int compare(Vertex i, Vertex j){
////                    if(i.getDistance() > j.getDistance()){
////                        return 1;
////                    }
////
////                    else if (i.getDistance() < j.getDistance()){
////                        return -1;
////                    }
////
////                    else{
////                        return 0;
////                    }
////                }
////            }
////
////        );
////
////        queue.add(source);
////
////        Set<Vertex> explored = new HashSet<Vertex>();
////        boolean found = false;
////
////        //while frontier is not empty
////        do{
////
////			Vertex current = queue.poll();
////            explored.add(current);
////
////
////            if(current.getName().matches(goal.getName())){
////                found = true;
////
////
////            }
////
////
////
////
////            for(Vertex child: current.getAdjacentCities()){
////
////            	Edge e = findEdge(child, current);
////
////                double cost = e.getCost();
////                child.setDistance(current.getDistance() + cost);
////
////                if(!explored.contains(child) && !queue.contains(child)){
////
////                    child.setPath(current);
////                    queue.add(child);
////
////                }
////                else if((queue.contains(child))&&(child.getDistance()>current.getDistance())){
////                    child.setPath(current);
////
////                    // the next two calls decrease the key of the node in the queue
////                    queue.remove(child);
////                    queue.add(child);
////                }
////
////
////            }
////        }while(!queue.isEmpty());
////
////return findVertex(goal);
//	}

	// Getters and setters
	public LinkedList<Edge> getEdges() {
		return edges;
	}

	public void setEdges(LinkedList<Edge> edges) {
		this.edges = edges;
	}

	public LinkedList<Vertex> getVertices() {
		return vertices;
	}

	public void setVertices(LinkedList<Vertex> vertices) {
		this.vertices = vertices;
	}

}

package com.example.pro4tic;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class rootController {
    @FXML
    private Button easy;

    @FXML
    private Button hard;

    @FXML
    private Button multi;
    
    @FXML
    private ImageView logo;

    public void multi(ActionEvent actionEvent) throws IOException {
        Node node = (Node) actionEvent.getSource();
        Stage thisStage = (Stage) node.getScene().getWindow();
        thisStage.hide();

        Stage stage=new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("root1.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 450, 518);
        stage.setTitle("Multiplayer");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    public void easy(ActionEvent actionEvent) throws IOException {
        Node node = (Node) actionEvent.getSource();
        Stage thisStage = (Stage) node.getScene().getWindow();
        thisStage.hide();

        Stage stage=new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("root2.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 450, 518);
        stage.setTitle("Random");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    public void hard(ActionEvent actionEvent) throws IOException {
        Node node = (Node) actionEvent.getSource();
        Stage thisStage = (Stage) node.getScene().getWindow();
        thisStage.hide();

        Stage stage=new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("root3.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 450, 518);
        stage.setTitle("Unbeatable");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }
}

package com.example.pro4tic;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

///easy

public class RandomA {
	private boolean tt = true;
	private boolean turnX = true;
	ArrayList<Button> arr = new ArrayList<Button>();

	@FXML
	private Button b1;

	@FXML
	private Button b2;

	@FXML
	private Button b3;

	@FXML
	private Button b4;

	@FXML
	private Button b5;

	@FXML
	private Button b6;

	@FXML
	private Button b7;

	@FXML
	private Button b8;

	@FXML
	private Button b9;

	@FXML
	private Button back;

	@FXML
	private Label state;

	@FXML
	private Button tryAgain;

	public void back(ActionEvent actionEvent) throws IOException {
		Node node = (Node) actionEvent.getSource();
		Stage thisStage = (Stage) node.getScene().getWindow();
		thisStage.hide();

		Stage stage = new Stage();
		FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("root.fxml"));
		Scene scene = new Scene(fxmlLoader.load(), 415, 380);
		stage.setScene(scene);
		stage.show();
		stage.setResizable(false);
	}

	public void again(ActionEvent actionEvent) throws IOException {
		Node node = (Node) actionEvent.getSource();
		Stage thisStage = (Stage) node.getScene().getWindow();
		thisStage.hide();

		Stage stage = new Stage();
		FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("root2.fxml"));
		Scene scene = new Scene(fxmlLoader.load(), 450, 518);
		stage.setScene(scene);
		stage.show();
		stage.setResizable(false);
	}

	public void initialize() {
		arr.add(b1);
		arr.add(b2);
		arr.add(b3);
		arr.add(b4);
		arr.add(b5);
		arr.add(b6);
		arr.add(b7);
		arr.add(b8);
		arr.add(b9);
		while (true) {
			Random random = new Random();
			int c = random.nextInt(9);
			if (arr.get(c).getText().equals("")) {
				arr.get(c).setText("X");
				arr.get(c).setFont(Font.font(70));
				arr.get(c).setStyle("-fx-background-color: Red");
				arr.get(c).setTextFill(Color.LEMONCHIFFON);
				arr.get(c).setDisable(true);
				turnX = false;
				break;
			}
		}
		for (int i = 0; i < arr.size(); i++) {
			int finalI = i;
			arr.get(i).setOnAction(e -> {

				arr.get(finalI).setText("O");
				arr.get(finalI).setFont(Font.font(70));
				arr.get(finalI).setStyle("-fx-background-color: DarkOliveGreen");
				arr.get(finalI).setTextFill(Color.LEMONCHIFFON);
				arr.get(finalI).setDisable(true);
				turnX = false;
				if (check().equals("X")) {
					state.setText("X Wons!");
					for (int x = 0; x < arr.size(); x++) {
						arr.get(x).setDisable(true);
						tt = false;
					}
				} else if (check().equals("O")) {
					state.setText("O Wons!");
					for (int x = 0; x < arr.size(); x++) {
						arr.get(x).setDisable(true);
						tt = false;
					}
				} else if (check().equals("tie")) {
					boolean temp = false;
					for (int j = 0; j < arr.size(); j++) {
						if (arr.get(j).getText().equalsIgnoreCase("")) {
							temp = true;
						}
					}
					if (!temp) {
						state.setText("tie !");
					}
				}
				while (tt) {
					Random random = new Random();
					int c = random.nextInt(9);
					if (arr.get(c).getText().equals("")) {
						arr.get(c).setText("X");
						arr.get(c).setFont(Font.font(70));
						arr.get(c).setStyle("-fx-background-color: Red");
						arr.get(c).setTextFill(Color.LEMONCHIFFON);
						arr.get(c).setDisable(true);
						turnX = false;
						break;
					}
				}
				if (check().equals("X")) {
					state.setText("X Wons!");
					for (int x = 0; x < arr.size(); x++) {
						arr.get(x).setDisable(true);
						tt = false;
					}
				} else if (check().equals("O")) {
					state.setText("O Wons!");
					for (int x = 0; x < arr.size(); x++) {
						arr.get(x).setDisable(true);
						tt = false;
					}
				} else if (check().equals("tie")) {
					boolean temp = false;
					for (int j = 0; j < arr.size(); j++) {
						if (arr.get(j).getText().equalsIgnoreCase("")) {
							temp = true;
						}
					}
					if (!temp) {
						state.setText("tie !");
					}
				}
			});

		}
	}

	private String check() {
		// parallel
		if ((b1.getText().equals("X") && b2.getText().equals("X") && b3.getText().equals("X"))
				|| (b1.getText().equals("O") && b2.getText().equals("O") && b3.getText().equals("O"))) {
			return b1.getText();
		} else if ((b4.getText().equals("X") && b5.getText().equals("X") && b6.getText().equals("X"))
				|| (b4.getText().equals("O") && b5.getText().equals("O") && b6.getText().equals("O"))) {
			return b4.getText();
		} else if ((b7.getText().equals("X") && b8.getText().equals("X") && b9.getText().equals("X"))
				|| (b7.getText().equals("O") && b8.getText().equals("O") && b9.getText().equals("O"))) {
			return b7.getText();

		}
		// perpendicular
		else if ((b1.getText().equals("X") && b4.getText().equals("X") && b7.getText().equals("X"))
				|| (b1.getText().equals("O") && b4.getText().equals("O") && b7.getText().equals("O"))) {
			return b1.getText();

		} else if ((b2.getText().equals("X") && b5.getText().equals("X") && b8.getText().equals("X"))
				|| (b2.getText().equals("O") && b5.getText().equals("O") && b8.getText().equals("O"))) {
			return b2.getText();

		} else if ((b3.getText().equals("X") && b6.getText().equals("X") && b9.getText().equals("X"))
				|| (b3.getText().equals("O") && b6.getText().equals("O") && b9.getText().equals("O"))) {
			return b3.getText();

		}

		// diagonal
		else if ((b1.getText().equals("X") && b5.getText().equals("X") && b9.getText().equals("X"))
				|| (b1.getText().equals("O") && b5.getText().equals("O") && b9.getText().equals("O"))) {
			return b1.getText();

		} else if ((b3.getText().equals("X") && b5.getText().equals("X") && b7.getText().equals("X"))
				|| (b3.getText().equals("O") && b5.getText().equals("O") && b7.getText().equals("O"))) {
			return b3.getText();

		}
		return "tie";
	}
}

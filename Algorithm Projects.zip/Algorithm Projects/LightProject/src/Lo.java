
public class Lo {

	public static void main(String[] args) {
		System.out.println("Hello");
		int[] a = { 10, 2, 3, 4, 5, 6, 7, 8 };
		int[] b = { 10, 2, 3, 4, 5, 6, 7, 8 };

		int num23 = 5;
		ReadFile file1 = new ReadFile();
		ReadFile num2;
//		System.out.println(longest(a, b));
		System.out.println(longesCommonSub(a, file1));
	}

	public static int[][] longest(int[][] num1, int[][] num2) {
		int m = num1.length;
		int n = num2.length;
		int[][] c = new int[m][n];
		String[][] b = new String[m][n];
		for (int i = 1; i <= m; i++) {
			c[i][0] = 0;
		}
		for (int j = 1; j <= n; j++) {
			c[0][j] = 0;
		}
		for (int i = 1; i <= m; i++) {
			for (int j = 1; j <= n; j++) {
				if (num1[i] == num2[j]) {
					c[i][j] = c[i - 1][j - 1] + 1;
					b[i][j] = "↖";

				} else if (num1[i][j - 1] > num2[i - 1][j]) {
					c[i][j] = c[i][j - 1];
					b[i][j] = "↤";
				} else {
					c[i][j] = c[i - 1][j];
					b[i][j] = "↥";
				}
			}
		}
		return c;
	}

	public static int longesCommonSub(int[] num1, ReadFile num2) {

		int m = num1.length;
		int n = num2.getData().length;

		int[][] arr = new int[m + 1][n + 1];
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				if (num1[i] == num2.getData()[j]) {
					arr[i][j] = arr[i + 1][j + 1] + 1;
					System.out.println("test");
				} else {
					arr[i][j] = Math.max(arr[i + 1][j], arr[i][j + 1]);
				}
			}
		}
		int i = 0;
		int j = 0;
		int sum = 0;
		while (i < m && j < n) {
			if (num1[i] == num2.getData()[j]) {
				sum = sum + (num1[i]);
				i++;
				j++;
			} else if (arr[i + 1][j] >= arr[i][j + 1]) {
				i++;
			} else {
				j++;
			}
		}
		return sum;
	}

}
